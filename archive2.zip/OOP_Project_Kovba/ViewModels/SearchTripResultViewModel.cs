﻿namespace OOP_Project_Kovba.ViewModels
{
    public class SearchTripResultViewModel
    {
        public List<TripResultViewModel> Trips { get; set; } = new List<TripResultViewModel>();
    }
}
