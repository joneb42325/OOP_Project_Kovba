﻿namespace OOP_Project_Kovba.ViewModels
{
    public class CreateBookingViewModel
    {
        public string TripId { get; set; } = string.Empty;
        public int PassengersCount { get; set; }
    }
}
